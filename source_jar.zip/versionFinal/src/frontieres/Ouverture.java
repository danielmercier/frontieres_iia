package frontieres;

public class Ouverture {
	public static final String[] ouvertureBlancs = {
			"D8-D7",
			"D7-D6",
	};
	public static final String[] ouvertureNoirs = {
			"D1-D2",
			"D2-D3",
	};
}
